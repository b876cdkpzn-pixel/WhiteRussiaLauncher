package ru.whiterussia.launcher

import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF10243D)
private val Blue = Color(0xFF58A6FF)
private val Muted = Color(0xFF9CB1C9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WhiteRussiaApp() }
    }
}

data class ServerInfo(val id: String, val name: String, val host: String, val port: Int, val online: Int?, val maxPlayers: Int?, val description: String)
data class NewsItem(val title: String, val text: String, val date: String)

@Composable
fun WhiteRussiaApp() {
    val context = LocalContext.current
    var servers by remember { mutableStateOf(listOf(ServerInfo("wr-main", "White Russia | Основной", "185.207.214.14", 6653, null, null, "Адрес указан владельцем; доступность не проверена."))) }
    var news by remember { mutableStateOf(listOf(NewsItem("White Russia — настройка сервера", "Адрес сервера добавлен. Игровой клиент и реальный онлайн ещё проверяются.", "2026-10-26"))) }
    var status by remember { mutableStateOf("Сервер добавлен · онлайн пока неизвестен") }
    var loading by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Главная") }
    var configUrl by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun refresh() {
        if (configUrl.isBlank()) {
            status = "Локальный сервер настроен. Для удалённых обновлений укажи HTTPS-ссылку в Настройках."
            return
        }
        if (!configUrl.startsWith("https://")) {
            status = "Нужна HTTPS-ссылка на JSON."
            return
        }
        loading = true
        status = "Загружаю конфигурацию…"
        scope.launch {
            try {
                val payload = withContext(Dispatchers.IO) { URL(configUrl).openConnection().apply { connectTimeout = 8000; readTimeout = 8000 }.getInputStream().bufferedReader().use { it.readText() } }
                val root = JSONObject(payload)
                val serverArray = root.optJSONArray("servers")
                val parsed = mutableListOf<ServerInfo>()
                if (serverArray != null) for (i in 0 until serverArray.length()) {
                    val s = serverArray.getJSONObject(i)
                    parsed += ServerInfo(
                        id = s.optString("id", "server-$i"), name = s.optString("name", "Без названия"),
                        host = s.optString("host", ""), port = s.optInt("port", 7777),
                        online = if (s.has("online") && !s.isNull("online")) s.optInt("online") else null,
                        maxPlayers = if (s.has("maxPlayers") && !s.isNull("maxPlayers")) s.optInt("maxPlayers") else null,
                        description = s.optString("description", "")
                    )
                }
                servers = parsed
                val nArray = root.optJSONArray("news")
                val parsedNews = mutableListOf<NewsItem>()
                if (nArray != null) for (i in 0 until nArray.length()) {
                    val n = nArray.getJSONObject(i)
                    parsedNews += NewsItem(n.optString("title", "Новость"), n.optString("text", ""), n.optString("date", ""))
                }
                news = parsedNews
                status = if (servers.isEmpty()) "Файл получен, но список серверов пуст" else "Конфигурация обновлена · ${servers.size} сервер(а)"
            } catch (e: Exception) {
                status = "Не удалось загрузить JSON. Проверь HTTPS-ссылку и формат файла."
            } finally { loading = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Navy).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(Blue, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Text("WR", color = Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("WHITE RUSSIA", fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text("SA-MP 0.3.7 · MOBILE LAUNCHER", fontSize = 10.sp, color = Muted, letterSpacing = 1.2.sp)
                }
                Text("0.1.0", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Главная", "Серверы", "Новости", "Настройки").forEach { tab ->
                    FilterChip(selected = selectedTab == tab, onClick = { selectedTab = tab }, label = { Text(tab, fontSize = 11.sp) })
                }
            }
            Spacer(Modifier.height(18.dp))
            when (selectedTab) {
                "Настройки" -> {
                    Text("ИСТОЧНИК ДАННЫХ", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = configUrl, onValueChange = { configUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("HTTPS-ссылка на servers.json") }, singleLine = true)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { refresh() }, enabled = !loading) { Text(if (loading) "Загрузка…" else "Загрузить конфигурацию") }
                    Spacer(Modifier.height(12.dp))
                    Text("Онлайн и максимум игроков отображаются только если их передаёт ваш JSON/API. Статический JSON не обеспечивает real-time онлайн.", color = Muted, fontSize = 12.sp)
                }
                "Новости" -> {
                    Text("ПОСЛЕДНИЕ НОВОСТИ", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    if (news.isEmpty()) Text("Новости появятся после загрузки конфигурации.", color = Muted)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(news) { n -> Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(14.dp)) { Text(n.title, fontWeight = FontWeight.Bold); if (n.date.isNotBlank()) Text(n.date, color = Blue, fontSize = 11.sp); Spacer(Modifier.height(5.dp)); Text(n.text, color = Muted, fontSize = 13.sp) } } } }
                }
                else -> {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("ТВОЯ ИГРА. ТВОИ ПРАВИЛА.", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Добро пожаловать в White Russia", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Сервер настроен: 185.207.214.14:6653. Адрес ещё не проверен, игровой клиент не подключён.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = { refresh() }, enabled = !loading, modifier = Modifier.fillMaxWidth()) { Text(if (loading) "Обновление…" else "Обновить серверы и новости") }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(status, color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("СЕРВЕРЫ", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    Spacer(Modifier.height(8.dp))
                    if (servers.isEmpty()) {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp)) { Text("Сервер ещё не добавлен", fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text("Сервер будет отображаться после загрузки конфигурации.", color = Muted, fontSize = 12.sp) } }
                    } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(servers) { s ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(14.dp)) {
                                    Text(s.name, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(4.dp))
                                    Text("${s.host}:${s.port}", color = Muted, fontSize = 12.sp)
                                    if (s.description.isNotBlank()) Text(s.description, color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text(if (s.online != null && s.maxPlayers != null) "Онлайн: ${s.online}/${s.maxPlayers}" else "Онлайн: нет данных от API", color = Blue, fontSize = 12.sp)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("White Russia server", "${s.host}:${s.port}"))
                                        status = "Адрес ${s.host}:${s.port} скопирован. Игровой клиент пока не подключён."
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Скопировать адрес") }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("White Russia 0.2.0 · адрес сервера задан · запуск игры не подключён", color = Muted, fontSize = 10.sp)
        }
    }
}
